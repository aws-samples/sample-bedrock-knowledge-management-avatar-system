import json
import boto3
import os
import logging
import time
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

transcribe = boto3.client('transcribe')
s3 = boto3.client('s3')

def lambda_handler(event, context):
    # If Lambda Custom Authorizer provides a response override, return response and stop
    if ('requestContext' in event and 'authorizer' in event['requestContext'] and 
        'responseOverrideString' in event['requestContext']['authorizer']):
        return json.loads(event['requestContext']['authorizer']['responseOverrideString'])
        
    try:
        # Get bucket and key from event
        print(json.dumps(event))
        bucket_name = os.environ['bucket']
        prefix = os.environ['prefix']
        if 'body' in event:
            body = json.loads(event['body'])
        else:
            body=event

        audio_key = body['audioKey']
        #time.sleep(4)
        
        
        #print(f'audiofile:{}')
        # Start transcription job
        job_name = f"transcribe-{audio_key.replace('.', '-')}-{int(time.time())}"
        MediaFileUri = f"s3://{bucket_name}/{prefix}audio/{audio_key}"
        OutputKey = f"{prefix}audio/transcripts/{job_name}.json"
        print(f'audiokey = {audio_key}')

        print(MediaFileUri)
        print(OutputKey)

        response = transcribe.start_transcription_job(
            TranscriptionJobName=job_name,
            Media={
                'MediaFileUri': MediaFileUri
            },
            MediaFormat='wav',
            LanguageCode='en-US',
            # Specify S3 output location (optional)
            OutputBucketName=bucket_name,
            OutputKey=OutputKey
        )
        
        # Wait for transcription to complete
        while True:
            status = transcribe.get_transcription_job(
                TranscriptionJobName=job_name
            )
            if status['TranscriptionJob']['TranscriptionJobStatus'] in ['COMPLETED', 'FAILED']:
                break
            time.sleep(1)
            
        if status['TranscriptionJob']['TranscriptionJobStatus'] == 'COMPLETED':
            # Get the transcript from S3
            try:
                transcript_object = s3.get_object(
                    Bucket=bucket_name,
                    Key=OutputKey
                )
                transcript_content = json.loads(transcript_object['Body'].read().decode('utf-8'))
                transcript_text = transcript_content['results']['transcripts'][0]['transcript']
                print(transcript_text)
                return {
                    'statusCode': 200,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Content-Type': 'application/json'
                    },
                    'body': json.dumps({
                        'transcription': transcript_text
                    })
                }
            except ClientError as e:
                logger.error(f"Error getting transcript from S3: {str(e)}")
                raise Exception("Failed to retrieve transcript from S3")
        else:
            failure_reason = status['TranscriptionJob'].get('FailureReason', 'Unknown error')
            raise Exception(f'Transcription failed: {failure_reason}')
            
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': str(e)
            })
        }
