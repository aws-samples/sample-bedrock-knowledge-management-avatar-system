import json
import os
import boto3
import random
import base64
import botocore
#

from botocore.client import Config
from botocore.exceptions import ClientError


#

dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')#, config=Config(signature_version='s3v4'))

def dyrm_rec(Id,table_name):
    # Initialize DynamoDB resource
    table = dynamodb.Table(table_name)
    try:
        # Delete the item with the specified key
        response = table.delete_item(
            Key={
                'id': Id
            }
        )
        return  f'Record with id {Id} successfully deleted.'
         
    except Exception as e:
        return   f'Error deleting record: {str(e)}'
 


def lambda_handler(event, context):
    # TODO implement
    _mess='hellow world'
    if 'body' in event:
        ebody = json.loads(event['body'])
        event['ebody'] = ebody
    else:
        ebody=event
    print(json.dumps(ebody))

  
    if 'delprompt' in  ebody:
        adminpw = os.environ['adminpw']
        TableName = os.environ['Dynamodb_name'] 
        if ebody['adminpw'] == adminpw :
            _mess = dyrm_rec(ebody['id'],TableName)
            
        else:
            _mess = 'Password in incorrect'
    
    _rret = {
                "statusCode": 200,
                "isBase64Encoded": False,
                'body': json.dumps({'message':_mess}),
                
                "headers": {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                }}
    return _rret
