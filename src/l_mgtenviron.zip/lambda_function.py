import json
import boto3
import os
from botocore.exceptions import ClientError

s3 = boto3.client('s3')
BUCKET = os.environ.get('CONFIG_BUCKET', 'your_default_config_bucket')
FILE_KEY = 'env_config.json'

def lambda_handler(event, context):

    # If Lambda Custom Authorizer provides a response override, return response and stop
    if ('requestContext' in event and 'authorizer' in event['requestContext'] and 
        'responseOverrideString' in event['requestContext']['authorizer']):
        return json.loads(event['requestContext']['authorizer']['responseOverrideString'])
        
    method = event.get('httpMethod', 'GET')
   
    if method == 'GET':
        return handle_get()
    elif method == 'POST':
        return handle_post(event)
    else:
        return create_response(400, {'error': 'Unsupported HTTP method'})

def handle_get():
    try:
        s3_response = s3.get_object(Bucket=BUCKET, Key=FILE_KEY)
        content = s3_response['Body'].read().decode('utf-8')
        data = json.loads(content)
        return create_response(200, data)
    except ClientError as e:
        # If the file doesn't exist, return default environment variables.
        if e.response['Error']['Code'] == 'NoSuchKey':
            default_data = {
                'variables': [
                    {'key': 'Unable to fetch', 'value': 'Reload page'},
                    # {'key': 'CONFIG_BUCKET', 'value': 'config-bucket-ao'}
                ]
            }
            return create_response(200, default_data)
        else:
            return create_response(500, {'error': 'Error fetching data from S3', 'message': str(e)})
    except Exception as e:
        return create_response(500, {'error': 'Error processing request', 'message': str(e)})

def handle_post(event):
    try:
        body = event.get('body')
        if not body:
            return create_response(400, {'error': 'Missing request body'})
        data = json.loads(body)
        # Validate that the request contains a 'variables' field.
        if 'variables' not in data:
            return create_response(400, {'error': "JSON must include a 'variables' key"})
       
        # Save the updated variables to S3.
        s3.put_object(Bucket=BUCKET, Key=FILE_KEY, Body=json.dumps(data))
        return create_response(200, {'message': 'Environment variables saved successfully', 'data': data})
    except Exception as e:
        return create_response(500, {'error': 'Error saving data to S3', 'message': str(e)})

def create_response(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body)
    }