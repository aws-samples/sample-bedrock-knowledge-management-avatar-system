import json
import os
import boto3


s3_client = boto3.client('s3')#, config=Config(signature_version='s3v4'))
bedrun = boto3.client('bedrock-runtime',region_name='us-east-1')


def bucket_get_obj(bucket, bkey):
    object = s3_client.get_object(Bucket=bucket, Key=bkey)
    return(object['Body'].read().decode('utf-8'))
def bucket_putpriv(bucket, key, body,type):
    srep = s3_client.put_object(
        ACL='private', Body=body, Bucket=bucket, Key=key, ContentType=type,)
    #print(srep)
    return srep    
def gen_surl(bucketname, keyname):
    url = s3_client.generate_presigned_url(ClientMethod='get_object', Params={'Bucket': bucketname, 'Key': keyname})
    return url
def bucket_key_exist(bucket,key):
    _ret=True
    try:
        rep = s3_client.get_object(Bucket=bucket, Key=key)
    except botocore.exceptions.ClientError as e:
        print(e.response['Error']['Code'])
        _ret= False
        if e.response['Error']['Code'] == "404":
            print(e.response['Error']['Code'])
            _ret= False
            
        else:
            # Something else has gone wrong.
            print(e.response['Error']['Code'])
    return _ret
 
def update_s3html(shtmls):
    for rr in shtmls:
        content = bucket_get_obj(shtmls[rr]['bucket'],shtmls[rr]['sourcekey'])
        for _rep in shtmls[rr]['replacments']:
            _repa=_rep.split('--')
            content = content.replace(_repa[0],_repa[1])
        bucket_putpriv(shtmls[rr]['bucket'],shtmls[rr]['key'],content,shtmls[rr]['ctype'])
    return 1

def lambda_handler(event, context):


    # TODO implement
    ########
    print(json.dumps(event))
    # If Lambda Custom Authorizer provides a response override, return response and stop
    if ('requestContext' in event and 'authorizer' in event['requestContext'] and 
        'responseOverrideString' in event['requestContext']['authorizer']):
        return json.loads(event['requestContext']['authorizer']['responseOverrideString'])
    


    bucket = os.environ['bucket']
    prefix = os.environ['prefix']

    kburl = os.environ['kburl']
    knowledge_base_id = os.environ['knowledge_base_id']
    model_arn = os.environ['model_arn']
    appId = os.environ['appId']

    uploadurl          = os.environ['uploadurl']
    displayfilesurl    = os.environ['displayfilesurl']
    PROMPT_HISTORY_URL = os.environ['PROMPT_HISTORY_URL']
    wssurl = os.environ['wssurl']

 
    
    imgprefix = f"{prefix}images"  
    
    event['bucket'] = bucket
    event['prefix'] = prefix
    event['imgprefix'] = imgprefix

    #
    tbstylekey=f"{prefix}web/css/demo1.css"
    scssdemo= gen_surl(bucket,tbstylekey)
    logokey    =f"{prefix}web/media/logob.png"
    slogo      = gen_surl(bucket,logokey)

    #
    #

    #https://9gu8gsuxc6.execute-api.us-east-1.amazonaws.com/bedpoc/dbfilemgt
    #
    #fix prompt_history_o.html.
    url_parts = kburl.split('.com')
    dbfilemgturl = f"{url_parts[0]}.com/bedpoc/dbfilemgt"
    reps=[]
    prompthistorykey         =     f"{prefix}web/prompt_history_o.html"
    prompthistory_out        =     f"{prefix}web/out/prompt_history.html"
    rep1 = f"__logo__--{slogo}"
    rep2 = f"__histurl__--{PROMPT_HISTORY_URL}"
    rep3 = f"__dbfilemgt__--{dbfilemgturl}"
 

    reps.append(rep1)
    reps.append(rep2)
    reps.append(rep3)
 
    s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':prompthistorykey,'key':prompthistory_out,'replacments':reps,'ctype':"text/html"}}
    update_s3html(s3updates)
    sprompthistory    =   gen_surl(bucket,prompthistory_out)
    ##
    
    #
    #fix upload_o.html.
    reps=[]
    upindexkey         =     f"{prefix}web/files_o.html"
    upindexkey_out     =     f"{prefix}web/out/files.html"
    rep1 = f"__logo__--{slogo}"
    rep2 = f"__uploadurl__--{uploadurl}"
    rep3 = f"__displayfilesurl__--{displayfilesurl}"

    reps.append(rep1)
    reps.append(rep2)
    reps.append(rep3)
    s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':upindexkey,'key':upindexkey_out,'replacments':reps,'ctype':"text/html"}}
    update_s3html(s3updates)
    supindexkey    =   gen_surl(bucket,upindexkey_out)
    ##


    #fix the js.
    reps=[]
    demojskey       =   f"{prefix}web/js/demo2js.js"
    demojskey_out     =   f"{prefix}web/js/out/demo2js.js"
    rep1 = f"__appid__--{appId}"
    reps.append(rep1)
    s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':demojskey,'key':demojskey_out,'replacments':reps,'ctype':"text/javascript"}}
    update_s3html(s3updates)
    sdemojskey    =   gen_surl(bucket,demojskey_out)
    ##


    text_autodemo_o    =f"{prefix}web/index_o.html"
    text_autodemo_out  =f"{prefix}web/out/index.html"


    reps=[]
 
    
    demojskey     =   f"{prefix}web/js/demo2js.js"
    


    #
    files_key   = f"{prefix}web/files_o.html"
    sfiles_key  = gen_surl(bucket,files_key)

    prompt_key   = f"{prefix}web/prompt_history_o.html"
    sprompt_key  = gen_surl(bucket,prompt_key)


    index_key   = f"{prefix}web/index_o.html"
    sindex_kes  = gen_surl(bucket,prompt_key)

   
    
    #
    uploadkey = f"{prefix}web/upindex.html"
    sploadkey    =   gen_surl(bucket,uploadkey)


    rep1 = f"css/demo1.css--{scssdemo}"
    rep2 = f"__kburl__--{kburl}"
    rep3 = f'__knowledge_base_id__--{knowledge_base_id}'
    rep4 = f'__model_arn__--{model_arn}'
    rep5 = f'__bucket__--{bucket}'
    rep6 = f'__logo__--{slogo}'
    rep7 = f'__demojs__--{sdemojskey}'
    rep8 = f'__upload__--{sploadkey}'
    rep9 = f'files.html--{supindexkey}'
    rep10 = f'prompt_history.html--{sprompthistory}'
    rep11 = f'index.html--{sploadkey}'
    
    
    #__transcribeurl__
    #__uploadurl__
    url_parts = uploadurl.split('.com')
    _trascribeurl = f"{url_parts[0]}.com/bedpoc/transcribe_audio"
    rep12 = f'__transcribeurl__--{_trascribeurl}'
    rep13 = f'__uploadurl__--{uploadurl}'
    
    rep14 = f'__wssurl__--{wssurl}'

    reps.append(rep1)
    reps.append(rep2)
    reps.append(rep3)
    reps.append(rep4)
    reps.append(rep5)
    reps.append(rep6)
    reps.append(rep7)
    reps.append(rep8)
    reps.append(rep9)
    reps.append(rep10)
    reps.append(rep11)

    reps.append(rep12)
    reps.append(rep13)

    reps.append(rep14)



     


    #s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':text_autodemo_o,'key':text_autodemo_out,'replacments':reps,'ctype':"text/html"}}
    
    s3updates = {'bedrock01':{'bucket':bucket,'sourcekey':index_key,'key':text_autodemo_out,'replacments':reps,'ctype':"text/html"}}
    


    
    
    update_s3html(s3updates)






    _rhtml = bucket_get_obj(bucket,text_autodemo_out)

 
    ctype='text/html'
    response = {
                            "statusCode": 200,
                            "body": _rhtml,
                           
                
                            "headers": {
                                'Content-Type': ctype,
                                'Access-Control-Allow-Origin': '*'
                            }}
    return response