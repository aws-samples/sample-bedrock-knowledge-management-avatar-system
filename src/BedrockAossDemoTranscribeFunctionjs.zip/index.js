const AWS = require('aws-sdk');
const { TranscribeStreamingClient, StartStreamTranscriptionCommand } = require('@aws-sdk/client-transcribe-streaming');
const { Readable } = require('stream');

const transcribeClient = new TranscribeStreamingClient({
    region: process.env.AWS_REGION || 'us-east-1'
});

const sessions = new Map();

class AudioStream extends Readable {
    constructor() {
        super();
        this.buffer = Buffer.alloc(0);
        this.isFinished = false;
    }

    _read() {}

    addChunk(chunk) {
        this.push(chunk);
    }

    finish() {
        this.isFinished = true;
        this.push(null);
    }
}

async function sendToClient(connectionId, message) {
    try {
        const endpoint = `https://${process.env.API_GATEWAY_ID}.execute-api.${process.env.AWS_REGION}.amazonaws.com/${process.env.STAGE}`;
        const apigwManagementApi = new AWS.ApiGatewayManagementApi({ endpoint });
        await apigwManagementApi.postToConnection({
            ConnectionId: connectionId,
            Data: JSON.stringify(message)
        }).promise();
    } catch (error) {
        console.error('Error sending to client:', error);
    }
}

exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    try {
        if (!event.requestContext) {
            return { statusCode: 400, body: 'Invalid request' };
        }

        const connectionId = event.requestContext.connectionId;
        const routeKey = event.requestContext.routeKey;

        if (routeKey === '$connect') return { statusCode: 200, body: 'Connected' };
        
        if (routeKey === '$disconnect') {
            await handleDisconnect(connectionId);
            return { statusCode: 200, body: 'Disconnected' };
        }

        if (routeKey !== 'sendAudio') {
            return { statusCode: 400, body: 'Invalid route' };
        }

        const body = JSON.parse(event.body);

        let session = sessions.get(connectionId);
        if (!session) {
            console.log("Creating new session for connection:", connectionId);
            const audioStream = new AudioStream();
            session = { 
                audioStream,
                transcriptionPromise: startTranscription(audioStream, connectionId)
            };
            sessions.set(connectionId, session);
        }

        if (body.data) {
            const audioData = Buffer.from(body.data, 'base64');
            console.log('Received audio chunk size:', audioData.length, 'for connection:', connectionId);
            session.audioStream.addChunk(audioData);
        }

        if (body.isFinal) {
            console.log('Finishing session for connection:', connectionId);
            session.audioStream.finish();
            await session.transcriptionPromise;
            sessions.delete(connectionId);
        }

        return { statusCode: 200, body: 'Processed' };

    } catch (error) {
        console.error('Error:', error);
        if (event?.requestContext?.connectionId) {
            await sendToClient(event.requestContext.connectionId, {
                type: 'error',
                message: error.message
            });
        }
        return { 
            statusCode: 500, 
            body: JSON.stringify({ error: error.message }) 
        };
    }
};

async function handleDisconnect(connectionId) {
    if (sessions.has(connectionId)) {
        const session = sessions.get(connectionId);
        session.audioStream.finish();
        try {
            await session.transcriptionPromise;
        } catch (error) {
            console.error('Error during disconnect cleanup:', error);
        } finally {
            sessions.delete(connectionId);
        }
    }
}

async function startTranscription(audioStream, connectionId) {
    try {
        console.log('Starting transcription for connection:', connectionId);
        const command = new StartStreamTranscriptionCommand({
            LanguageCode: "en-US",
            MediaSampleRateHertz: 16000,
            MediaEncoding: "pcm",
            AudioStream: async function* () {
                for await (const chunk of audioStream) {
                    yield { AudioEvent: { AudioChunk: chunk }};
                }
            }(),
            EnablePartialResultsStabilization: true,
            PartialResultsStability: 'high'
        });
        
        const response = await transcribeClient.send(command);
        console.log('Transcription started for connection:', connectionId);
        
        for await (const event of response.TranscriptResultStream) {
            console.log('Received transcription event for connection:', connectionId, JSON.stringify(event, null, 2));
            if (event.TranscriptEvent?.Transcript?.Results?.[0]?.Alternatives?.[0]?.Transcript) {
                const transcript = event.TranscriptEvent.Transcript.Results[0].Alternatives[0].Transcript;
                const isFinal = !event.TranscriptEvent.Transcript.Results[0].IsPartial;
                
                console.log('Transcription:', {
                    text: transcript.trim(),
                    isFinal: isFinal,
                    connectionId: connectionId
                });

                await sendToClient(connectionId, {
                    type: 'transcription',
                    text: transcript.trim(),
                    isFinal: isFinal
                });
            }
        }
    } catch (error) {
        console.error('Transcription error for connection:', connectionId, error);
        await sendToClient(connectionId, {
            type: 'error',
            message: error.message
        });
    }
}