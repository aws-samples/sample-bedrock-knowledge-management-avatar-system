import json
import boto3
from boto3.dynamodb.conditions import Key
from decimal import Decimal
import datetime
import os

dynamodb = boto3.resource('dynamodb')
tablename= os.environ.get('Dynamodb_name')
table = dynamodb.Table(tablename) 

# Helper class to handle Decimal serialization
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return str(obj)
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()
        return super(DecimalEncoder, self).default(obj)

import boto3

def dyrm_rec(Id,table_name):
    # Initialize DynamoDB resource
    dynamodb = boto3.resource('dynamodb')
    
    # Specify the table name
   
    table = dynamodb.Table(table_name)
    
    try:
        # Delete the item with the specified key
        response = table.delete_item(
            Key={
                'id': Id
            }
        )
        return  f'Record with id {Id} successfully deleted.'
         
    except Exception as e:
        return   f'Error deleting record: {str(e)}'
         

def lambda_handler(event, context):
    # If Lambda Custom Authorizer provides a response override, return response and stop
    if ('requestContext' in event and 'authorizer' in event['requestContext'] and 
        'responseOverrideString' in event['requestContext']['authorizer']):
        return json.loads(event['requestContext']['authorizer']['responseOverrideString'])
    try:
        # Scan the table to get all items
        response = table.scan()
        items = response['Items']
        
        # Sort items by timestamp in descending order
        sorted_items = sorted(items, key=lambda x: x['timestamp'], reverse=True)
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET'
            },
            'body': json.dumps(
                {'items': sorted_items}, 
                cls=DecimalEncoder
            )
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }
