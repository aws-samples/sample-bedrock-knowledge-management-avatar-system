import json
import boto3
import os
import logging
from botocore.exceptions import ClientError
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')
def bucket_rm_key(bucket,key):
        # Delete the object
        _ret = s3_client.delete_object(Bucket=bucket, Key=key)
        return _ret
def lambda_handler(event, context):
    print(json.dumps(event))
    # If Lambda Custom Authorizer provides a response override, return response and stop
    if ('requestContext' in event and 'authorizer' in event['requestContext'] and 
        'responseOverrideString' in event['requestContext']['authorizer']):
        return json.loads(event['requestContext']['authorizer']['responseOverrideString'])
    bucket_name = ''
    prefix = ''

    try:
        
        if 'body' in event:
            body =  json.loads(event['body'])
        else:
            body= event
        print(json.dumps(body))

        if 'deldafile' in body:
            
            dfile= body.get('fileName', '')
            bucket_name = os.environ['kbbucket']
            prefix = os.environ['prefix'] + "kbuploads/"
            adminpw = os.environ['adminpw'] 
            if body['adminpw'] == adminpw :
                dkey = f"{prefix}{dfile}"
                bucket_rm_key(bucket_name,dkey)
                _mess = f'{dfile} has been deleted'
            else:
                _mess = 'Password in incorrect'

            return {
            'statusCode': 200,
            'headers': {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'message':_mess})
            }


        file_name = body.get('fileName', '')
        file_content = body.get('contentType', '')
        username = body.get('username', 'Unknown')
        date_uploaded = body.get('dateUploaded', datetime.now().isoformat())


        if file_content == 'audio/wav':
            prefix = os.environ['prefix'] + "audio/"
            bucket_name = os.environ['bucket']
        else:
            bucket_name = os.environ['kbbucket']
            prefix = os.environ['prefix'] + "kbuploads/"
        print(f'bucketname: {bucket_name}')
        print(f'fileName: {file_name}')
        print(f'Content: {file_content}')
        # Generate presigned URL with metadata fields allowed
        presigned_url = s3_client.generate_presigned_post(
            Bucket=bucket_name,
            Key=f"{prefix}{file_name}",
            Fields={
                'Content-Type': file_content,
                'x-amz-meta-username': username,
                'x-amz-meta-dateuploaded': date_uploaded
                
            },
            Conditions=[
                {'Content-Type': file_content},
                ['starts-with', '$x-amz-meta-username', ''],
                ['starts-with', '$x-amz-meta-dateuploaded', '']
            ]
        )
        
        return {
            'statusCode': 200,
            'headers': {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
            'body': json.dumps(presigned_url)
        }
        
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'error': str(e)
            })
        }