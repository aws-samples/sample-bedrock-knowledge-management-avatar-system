import json
import boto3
import os
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    print(json.dumps(event))
    try:
        bucket_name = os.environ['kbbucket']
        prefix = os.environ['prefix']
        
        # List all objects in the uploads folder
        response = s3_client.list_objects_v2(
            Bucket=bucket_name,
            Prefix=f'{prefix}kbuploads/'
        )
        
        files = []
        for obj in response.get('Contents', []):
            try:
                # Get metadata for each object
                head_response = s3_client.head_object(
                    Bucket=bucket_name,
                    Key=obj['Key']
                )
                
                # Extract metadata
                metadata = head_response.get('Metadata', {})
                logger.info(f"Retrieved metadata: {metadata}")
                
                files.append({
                    'fileName': obj['Key'].split('/')[-1],
                    'username': metadata.get('username', 'Unknown'),
                    'dateUploaded': metadata.get('dateuploaded', obj['LastModified'].isoformat()),
                    'size': obj['Size'],
                    'lastModified': obj['LastModified'].isoformat()
                })
                
            except Exception as e:
                logger.error(f"Error getting metadata for {obj['Key']}: {str(e)}")
                # Still include the file, but with default values
                files.append({
                    'fileName': obj['Key'].split('/')[-1],
                    'username': 'Unknown',
                    'dateUploaded': obj['LastModified'].isoformat(),
                    'size': obj['Size'],
                    'lastModified': obj['LastModified'].isoformat()
                })

        # Sort files by upload date (newest first)
        files.sort(key=lambda x: x['dateUploaded'], reverse=True)
        
        return {
            'statusCode': 200,
            'headers': {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'files': files,
                'count': len(files)
            })
        }
        
    except Exception as e:
        logger.error(f"Error listing files: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'ContentType':'application/json','Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'error': str(e)
            })
        }